<?php
error_reporting(E_ALL);



function generic_error_handler($nError, $strError, $strFile = "", $nErrorLine = 0 , $arrErrorContext = array())
{
	$strErrorDetail = "<File: >".$strFile." Line: ".$nErrorLine." ErrorNumber: ";
	$strErrorDetail.= $nError." Error: ".$strError."\n";
	echo $strErrorDetail;
}
set_error_handler("generic_error_handler"); 
defined('BASEPATH') OR exit('No direct script access allowed');
class Home extends CI_Controller {

    public function __construct() {
        parent::__construct();
        #Load Model
        $this->load->model(array('crawlmodel', 'trackermodel', 'mastermodel', 'batchlogs'));
    }
	

    public function index() {
        isUserLogin(TRUE);
        $data['vendors'] = $this->mastermodel->getAllVendor();
        $data['regions'] = $this->mastermodel->getAllRegion();
        $data['markets'] = $this->mastermodel->getAllMarket();

        $data['title'] = 'upload POs';
        $data['menu_id'] = 'opupload';
        $data['page_heading'] = 'upload POs';
        $data['view_file'] = 'home/file_upload';
        if ($this->session->flashdata('formdata')) {
            $formdata = $this->session->flashdata('formdata');
            if (isset($formdata['upload'])) {
                $data['batch_id'] = $formdata['batch_id'];
                $data['fileUploadData'] = $this->batchlogs->getFileUploadStatusCount($data['batch_id']);
                $data['fileUploadStatus'] = $this->batchlogs->getFileUploadStatus();
            }
        }
        view($data);
    }

    public function handel_upload() { 

        
        if (isUserLogin()) {
            
            $config['upload_path'] = UPLOAD;
            $config['allowed_types'] = 'pdf';
            $config['overwrite'] = FALSE;
            $config['file_ext_tolower'] = TRUE;
            $config['encrypt_name'] = TRUE;
            $config['remove_spaces'] = TRUE;
            $config['detect_mime'] = TRUE;
            $config['mod_mime_fix'] = TRUE;
            $config['max_size'] = 5120;
            $this->load->library('upload');
            $this->upload->initialize($config);
            if ($_POST['submit']) {
                
                $this->load->library('form_validation');
                $this->form_validation->set_rules('region', 'Region', 'trim|xss_clean|required|is_natural_no_zero');
                $this->form_validation->set_rules('customer', 'Customer', 'trim|xss_clean|required|is_natural_no_zero');
                $this->form_validation->set_rules('market', 'Market', 'trim|xss_clean|required|is_natural_no_zero');
                if ($this->form_validation->run() == TRUE) {
                    $region = $formdata['region'] = $this->input->post('region');
                    $customer = $formdata['customer'] = $this->input->post('customer');
                    $customerNameArr = $this->mastermodel->getVendorByID($customer);
                    $customerName = $customerNameArr['name'];
                    $crawlFunction = "";
                    if (strpos(strtolower($customerName), 'velocitel') !== false) {
                        $crawlFunction = 'crawlVelocitel';
                    } else if (strpos(strtolower($customerName), 'mastec') !== false) {
                        $crawlFunction = 'crawlMastec';
                    } else if (strpos(strtolower($customerName), 'black & veatch') !== false) {
                        $crawlFunction = 'crawlBV';
                    } else if (strpos(strtolower($customerName), 'sai') !== false) {
                        $crawlFunction = 'crawlSAI';
                    }
                 
                    //echo $crawlFunction;
                    //die();
                    $market = $formdata['market'] = $this->input->post('market');
                    $formdata['batch_id'] = 0;
                    $this->session->set_flashdata('formdata', $formdata); 
                    if (isset($_FILES['attachment']) && !empty($_FILES['attachment']['name'])) {
                        

                        include APPPATH . 'third_party/PdfToText/PdfToText.phpclass';
                        $filesCount = count($_FILES['attachment']['name']);
                        $fileUploadStatus = $this->batchlogs->getFileUploadStatus();
						echo "<pre>";
						print_r( $fileUploadStatus);
                        for ($i = 0; $i < $filesCount; $i++) { 
                            $pdf_name = $_FILES['attachment']['name'][$i];
                            /********************************/
                            $pdf_name_keys = explode("-",$pdf_name);
                            $regAbv = substr($pdf_name_keys[1], 0, 2);
                            
                            $fileExist = $this->crawlmodel->checkFileNameExists($pdf_name);
							
                            if ($fileExist) {
                                //add duplicate file
                                if ($formdata['batch_id'] == 0) {
                                    //insert upload log
                                    $formdata['upload'] = TRUE;
                                    $formdata['batch_id'] = $this->batchlogs->addUploadLog();
                                    $this->session->set_flashdata('formdata', $formdata);
                                }
                                //insert file name by upload log
                                $this->batchlogs->addFileUploadMap($formdata['batch_id'], $pdf_name, $fileUploadStatus['duplicate']);
                                continue;
                            }
                            $_FILES['userFile']['name'] = $_FILES['attachment']['name'][$i];
                            $_FILES['userFile']['type'] = $_FILES['attachment']['type'][$i];
                            $_FILES['userFile']['tmp_name'] = $_FILES['attachment']['tmp_name'][$i];
                            $_FILES['userFile']['error'] = $_FILES['attachment']['error'][$i];
                            $_FILES['userFile']['size'] = $_FILES['attachment']['size'][$i];
                            
                            if (!$this->upload->do_upload('userFile')) { 
                                //echo __LINE__;
                                //exit;
                                //add error file                                
                                if ($formdata['batch_id'] == 0) {
                                    //insert upload log
                                    $formdata['upload'] = TRUE;
                                    $formdata['batch_id'] = $this->batchlogs->addUploadLog();
                                    $this->session->set_flashdata('formdata', $formdata);
                                }
                                //insert file name by upload log
                                $this->batchlogs->addFileUploadMap($formdata['batch_id'], $pdf_name, $fileUploadStatus['error']);
                                continue;
                                //$this->session->set_flashdata('error_message', $this->upload->display_errors());                               
                            } else {
                                $upFile = $this->upload->data();
                                $file_name = $upFile['file_name'];

                                //insert crawl log with status pending
                                $crawId = $this->crawlmodel->addCrawlLog($file_name, $pdf_name, '', $customer, 2);
								echo "CrwId:$crawId"; 
                                //echo $crawId = 2;
                                if ($crawId) {
                                    $pdf = new PdfToText(NULL, PdfToText::PDFOPT_BASIC_LAYOUT);
                                    $pdf->BlockSeparator = "@@";
                                    $pdf->load($upFile['full_path']); //echo $pdf->Text;//exit;
                                    $lines = explode("\n", $pdf->Text);
									#echo "<pre>";
									#print_r($lines);exit;
                                    $foundrow = FALSE;
                                    $ponumber = $POdate = $codate = '';
                                    $uploadOk = TRUE;
                                    $rev = 0;
                                    $isrev = FALSE;
                                    $orders = array();
                                    $orderkey = 0;
                                    //added by rajarshi
                                    $siteID = "";
                                    $supplier_no_flag = FALSE;
                                    $errorTrackerFlag = FALSE;
                                    $supplier_no = "";
                                    $orderDetails = array();
                                    #echo "<pre>";
                                    if ($crawlFunction == 'crawlMastec') {
										
                                        $contRemove = FALSE;
                                        foreach ($lines as $linekey => $line) {
                                            if(preg_match('/Proprietary and Confidential/', $line)){
                                                unset($lines[$linekey]);
                                                $contRemove = TRUE;
                                            }
                                            if($contRemove == TRUE && $line == ""){
                                                unset($lines[$linekey]);
                                            }
                                            if($contRemove == TRUE && preg_match('/Standard Purchase Order/', $line)){
                                                unset($lines[$linekey]);
                                                $contRemove = FALSE;
                                            }
                                        }
                                        foreach ($lines as $linekey => $line) {
                                            //print_r($line);
                                            if (preg_match('/@@Order@@/', $line)) {
                                                $temp = explode($pdf->BlockSeparator, $line);
                                                $found = FALSE;
                                                foreach ($temp as $value) {
                                                    if ($found) {
                                                        $found = FALSE;
                                                        $ponumber = trim($value);
                                                        break;
                                                    }
                                                    if (strtolower(trim($value)) == 'order') {
                                                        $found = TRUE;
                                                    }
                                                }
                                            }

                                            if (preg_match('/@@Revision@@/', $line)) {
                                                $temp = explode($pdf->BlockSeparator, $line);
                                                $found = FALSE;
                                                foreach ($temp as $value) {
                                                    if ($found) {
                                                        $found = FALSE;
                                                        $rev = trim($value);
                                                        break;
                                                    }
                                                    if (strtolower(trim($value)) == 'revision') {
                                                        $found = TRUE;
                                                    }
                                                }
                                                if (!empty($ponumber)) {
                                                    //check po no and revision and vendor
                                                    $orderDetails = $this->trackermodel->getOrderDetils($customer, $ponumber);
                                                    if ($orderDetails) {
                                                        //check rev
                                                        if ($orderDetails['revision'] > $rev) {
                                                            //add duplicate file                                                    
                                                            if ($formdata['batch_id'] == 0) {
                                                                //insert upload log
                                                                $formdata['upload'] = TRUE;
                                                                $formdata['batch_id'] = $this->batchlogs->addUploadLog();
                                                                $this->session->set_flashdata('formdata', $formdata);
                                                            }
                                                            //insert file name by upload log
                                                            $this->batchlogs->addFileUploadMap($formdata['batch_id'], $pdf_name, $fileUploadStatus['duplicate']);
                                                            //$this->session->set_flashdata('error_message', 'an upper or same revision already added in server');
                                                            $uploadOk = FALSE;
                                                            break;
                                                        }
                                                    }
                                                } else {
                                                    //some error                                                
                                                    if ($formdata['batch_id'] == 0) {
                                                        //insert upload log
                                                        $formdata['upload'] = TRUE;
                                                        $formdata['batch_id'] = $this->batchlogs->addUploadLog();
                                                        $this->session->set_flashdata('formdata', $formdata);
                                                    }
                                                    //insert file name by upload log
                                                    $this->batchlogs->addFileUploadMap($formdata['batch_id'], $pdf_name, $fileUploadStatus['error']);
                                                    //$this->session->set_flashdata('error_message', 'error in  pdf file');
                                                    $uploadOk = FALSE;
                                                    break;
                                                }
                                            }

                                            if (preg_match('/Order Date/', $line)) {
                                                $temp = explode($pdf->BlockSeparator, $line);
                                                $found = FALSE;
                                                foreach ($temp as $value) {
                                                    if ($found) {
                                                        $found = FALSE;
                                                        $POdate = date("Y-m-d", strtotime(trim($value)));
                                                        break;
                                                    }
                                                    if (strtolower(trim($value)) == 'order date') {
                                                        $found = TRUE;
                                                    }
                                                    if (preg_match('/Order Date/', trim($value)) && !$found) {
                                                        $POdate = date("Y-m-d", strtotime(trim(str_replace('Order Date', '', $value))));
                                                    }
                                                }
                                            }

                                            if (preg_match('/FA Code/', $line)) {
                                                $temp = explode($pdf->BlockSeparator, $line);
                                                $found = FALSE;
                                                foreach ($temp as $value) {
                                                    if ($found) {
                                                        $found = FALSE;
                                                        $state_name = trim($value);
                                                        break;
                                                    }
                                                    if (strtolower(trim($value)) == 'fa code') {
                                                        $found = TRUE;
                                                    }
                                                }
                                            }

                                            if (preg_match('/Project#/', $line)) {
                                                $temp = explode($pdf->BlockSeparator, $line);
                                                $found = FALSE;
                                                foreach ($temp as $value) {
                                                    if ($found) {
                                                        $found = FALSE;
                                                        $supplier_no = trim($value);
                                                        break;
                                                    }
                                                    if (strtolower(trim($value)) == 'project#') {
                                                        $found = TRUE;
                                                    }
                                                }
                                            }

                                            if ($foundrow == TRUE && preg_match('/Total:/', $line)) {
                                                $foundrow = FALSE;
                                            }
                                            if ($foundrow == TRUE) {
                                                #echo "<------->>";print_r($line);echo "<<<------->>\n";
                                                $temp = explode($pdf->BlockSeparator, $line);
                                               /*  echo "<br>";
												echo "Desc:".trim($orders[$orderkey]['description']);
												 echo "<br>";
												 $test = preg_match('/Line@@Part Number \/ Description@@Delivery Date\/Time@@Quantity@@UOM@@Unit Price@@Tax@@Amount/', $line);
												 echo "test:<pre>";
												 print_r($test);
												 echo "loop close\n"; */
                                                /************##################****************/
                                                if(preg_match('/Line@@Part Number \/ Description@@Delivery Date\/Time@@Quantity@@UOM@@Unit Price@@Tax@@Amount /', $line) ){
                                                    $waitForNewRow = TRUE;
                                                    $waitForNewRowCount = 2;
                                                    #echo "DESC****:".$orders[$orderkey]['description'];
													#exit;
                                                }
                                                /************##################****************/

                                                if ($chkDesNxtLine && $chkDesNxtLine > 0) {
                                                    if($waitForNewRow == TRUE){
                                                                if($waitForNewRowCount-- == 0){
                                                                    $orders[$orderkey]['description'] = trim($line);
                                                                    $chkDesNxtLine--;
                                                                    $waitForNewRow = FALSE;
                                                                }
                                                            }else{
                                                                if ($chkDesNxtLine == 1) {
                                                                    if($orders[$orderkey]['description']){
                                                                        $orders[$orderkey]['description'] = $orders[$orderkey]['description'] . " \n" . trim($line);
                                                                    }else{
                                                                        $orders[$orderkey]['description'] = trim($line);
                                                                    }

                                                                }
                                                                $chkDesNxtLine--;
                                                            }
                                                }

                                                if (isset($temp[0]) && ctype_digit($temp[0])) {
                                                    //echo count($temp);
                                                    //print_r($temp);
                                                    if (count($temp) == 8) {
                                                        $orderkey++;
                                                        $orders[$orderkey]['line'] = intval(trim($temp[0]));
                                                        $orders[$orderkey]['description'] = trim($temp[1]);
                                                        $orders[$orderkey]['qty'] = trim($temp[3]);
                                                        $orders[$orderkey]['state_name'] = isset($state_name) ? $state_name : '';
                                                        $orders[$orderkey]['unite_price'] = trim(str_replace(['$', ','], '', $temp[5]));
                                                        $orders[$orderkey]['amount'] = trim(str_replace(['$', ','], '', $temp[7]));
                                                        $chkDesNxtLine = 2;
                                                        //add rev row
                                                    } else if (count($temp) == 7) {
                                                        $orderkey++;
                                                        $orders[$orderkey]['line'] = intval(trim($temp[0]));
                                                        $orders[$orderkey]['description'] = trim($temp[1]);
                                                        $orders[$orderkey]['qty'] = trim($temp[2]);
                                                        $orders[$orderkey]['state_name'] = isset($state_name) ? $state_name : '';
                                                        $orders[$orderkey]['unite_price'] = trim(str_replace(['$', ','], '', $temp[4]));
                                                        $orders[$orderkey]['amount'] = trim(str_replace(['$', ','], '', $temp[6]));
                                                        $chkDesNxtLine = 1;
                                                        //add rev row
                                                    } else if (count($temp) == 6) {
                                                        $orderkey++;
                                                        $orders[$orderkey]['line'] = intval(trim($temp[0]));
                                                        $orders[$orderkey]['description'] = "";
                                                        $orders[$orderkey]['qty'] = trim($temp[1]);
                                                        $orders[$orderkey]['state_name'] = isset($state_name) ? $state_name : '';
                                                        $orders[$orderkey]['unite_price'] = trim(str_replace(['$', ','], '', $temp[3]));
                                                        $orders[$orderkey]['amount'] = trim(str_replace(['$', ','], '', $temp[5]));
                                                        $chkDesNxtLine = 1;
                                                        //add rev row
                                                    }else {
                                                        //some error                                                
                                                        if ($formdata['batch_id'] == 0) {
                                                            //insert upload log
                                                            $formdata['upload'] = TRUE;
                                                            $formdata['batch_id'] = $this->batchlogs->addUploadLog();
                                                            $this->session->set_flashdata('formdata', $formdata);
                                                        }
                                                        //insert file name by upload log
                                                        $this->batchlogs->addFileUploadMap($formdata['batch_id'], $pdf_name, $fileUploadStatus['error']);
                                                        //$this->session->set_flashdata('error_message', 'error in  pdf file');
                                                        $uploadOk = FALSE;
                                                        break;
                                                    }
                                                }
                                            }
                                            if ($foundrow == FALSE && preg_match('/Line@@Part Number \/ Description@@Delivery Date\/Time@@Quantity@@UOM@@Unit Price@@Tax@@Amount/', $line)) {
                                                $foundrow = TRUE;
                                                if ($rev) {
                                                    $isrev = TRUE;
                                                } else {
                                                    $isrev = FALSE;
                                                }
                                            }
                                        }
                                    } 
                                                   
                                    else {
                                        $this->session->set_flashdata('error_message', 'There is some mismatch with the Vendor');
                                    }
												
                                    if ($uploadOk) {
                                        //check ponumber and order exist
                                      # echo "AAAA";
                                        if (!empty($ponumber) && !empty($orders) || !empty($order_ids_new)) {
                                       #  echo "BBBBB";
                                            if ($orderDetails) {
                                                //update in tracker and order


                                                $this->trackermodel->updateOrder($orderDetails['order_id'], $rev, $file_name, $pdf_name);
												$last_rev = $this->trackermodel->getTrackerLastRev($customer, $ponumber);

												if(is_array($last_rev))
												{
													$affected_rows = $this->trackermodel->updateStatus($customer, $ponumber,$last_rev[0]['max_rev']);
													
												}
		
                                                foreach ($orders as $order) {
                                                    /* check for error in order */
                                                    if($order['line'] == "" || $order['line'] == 0 || $order['line'] == '0'
                                                        || $POdate == "" || $POdate == '0000-00-00' || $POdate == '1970-01-01'
                                                        
                                                        || trim($order['description']) == ""
                                                        || $order['unite_price'] == ""
                                                        
                                                        || $supplier_no == ""   ) {
                                                            $this->trackermodel->addTrackerError($region, $market, $customer, $ponumber, $order['line'], $POdate, $order['state_name'], $order['description'], $order['unite_price'], $order['amount'], $order['qty'], $rev, $supplier_no);
                                                            $errorTrackerFlag = TRUE;
															
                                                        }else{
															
															$arraDesc = explode(',',$order['description']);
															$order['state_name'] = $arraDesc[0];
                                                            $this->trackermodel->addTracker($region, $market, $customer, $ponumber, $order['line'], $POdate, $order['state_name'], $order['description'], $order['unite_price'], $order['amount'], $order['qty'], $rev, $supplier_no);
                                                        } 
                                                }
                                            } else {
                                                //insert in tracker and order
                                                $this->trackermodel->addOder($ponumber, $rev, $file_name, $pdf_name, $customer);
                                                foreach ($orders as $order) {
                                                    /* check for error in order */
                                                    if($order['line'] == "" || $order['line'] == 0 || $order['line'] == '0'
                                                        || $POdate == "" || $POdate == '0000-00-00' || $POdate == '1970-01-01'
                                                        || $order['state_name'] == ""
                                                        || trim($order['description']) == ""
                                                        || $order['unite_price'] == ""
                                                        || $order['qty'] == "" || $order['qty'] == 0 || $order['qty'] == '0'
                                                        || $supplier_no == ""   ) {
                                                            $this->trackermodel->addTrackerError($region, $market, $customer, $ponumber, $order['line'], $POdate, $order['state_name'], $order['description'], $order['unite_price'], $order['amount'], $order['qty'], $rev, $supplier_no);
                                                            $errorTrackerFlag = TRUE;
                                                        }else{
                                                            $this->trackermodel->addTracker($region, $market, $customer, $ponumber, $order['line'], $POdate, $order['state_name'], $order['description'], $order['unite_price'], $order['amount'], $order['qty'], $rev, $supplier_no);
                                                        }
                                                }
                                            }
                                            //make crawl log success rev and po no                                            
                                            if ($formdata['batch_id'] == 0) {
                                                //insert upload log
                                                $formdata['upload'] = TRUE;
                                                $formdata['batch_id'] = $this->batchlogs->addUploadLog();
                                                $this->session->set_flashdata('formdata', $formdata);
                                            }
											// Code inserted by Virat
											if ($formdata['batch_id'] == '') {
														$formdata['batch_id']= $order['description'];
											}
												     
                                            //insert file name by upload log
                                            $this->batchlogs->addFileUploadMap($formdata['batch_id'], $pdf_name, $fileUploadStatus['uploaded']);
                                            //$this->session->set_flashdata('success_message', 'upload complete.');
                                            $fileExist = $this->crawlmodel->updatelog($crawId, 3, $ponumber, $rev);
                                            continue;
                                        } else {
											 echo "CCCC";
											 
                                            //add error log
                                            if ($formdata['batch_id'] == 0) {
                                                //insert upload log
                                                $formdata['upload'] = TRUE;
                                                $formdata['batch_id'] = $this->batchlogs->addUploadLog();
                                                $this->session->set_flashdata('formdata', $formdata);
                                            }
                                            //insert file name by upload log
                                            $this->batchlogs->addFileUploadMap($formdata['batch_id'], $pdf_name, $fileUploadStatus['error']);
                                            //$this->session->set_flashdata('error_message', 'error in  pdf file');
                                            continue;
                                        }
                                    }
                                } else {
									
                                    //add error log
                                    if ($formdata['batch_id'] == 0) {
                                        //insert upload log
                                        $formdata['upload'] = TRUE;
                                        $formdata['batch_id'] = $this->batchlogs->addUploadLog();
                                        $this->session->set_flashdata('formdata', $formdata);
                                    }
                                    //insert file name by upload log
                                    $this->batchlogs->addFileUploadMap($formdata['batch_id'], $pdf_name, $fileUploadStatus['error']);
                                    continue;
                                }
                            }
                        }
                        //die('------------------||||||-------------');
                        $extMsg = ""; 
                        if($errorTrackerFlag == TRUE){
                            $extMsg = '<span style="color:red; font-width:bolder"> There are some tracker with wrong data. Please check the errors section.</span>';
                        }
                        $this->session->set_flashdata('success_message', 'upload complete.'.$extMsg);
                        redirect('home');
                    } else {
                        $this->session->set_flashdata('error_message', 'Please upload a pdf file');
                        redirect('home');
                    }
                } else {
                    $this->session->set_flashdata('error_message', validation_errors());
                    redirect('home');
                }
            } else {
                $this->session->set_flashdata('error_message', 'Error ocure when upload your data!');
                redirect('home');
            }
        } else {
            redirect('home');
        }
    }

    public function download_report($upload_id = 0) {
        if (isUserLogin()) {
            $uploadId = xss_clean($upload_id);
            $this->load->library('excelphp');
            $fileUploadData = $this->batchlogs->getFileUploadMap($uploadId);
            if ($fileUploadData) {
                $fileUploadStatus = $this->batchlogs->getFileUploadStatus();
                $ploadStatus = array_flip($fileUploadStatus);
                $row = 1;
                $this->excelphp->setActiveSheetIndex(0);
                $this->excelphp->getActiveSheet()->setTitle('File Uplaod Report');
                $this->excelphp->getActiveSheet()
                        ->getStyle('A' . $row . ':H' . $row)
                        ->getFill()
                        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
                        ->getStartColor()
                        ->setARGB('#FFFF00');
                $this->excelphp->getActiveSheet()->setCellValue('A' . $row, 'File Name');
                $this->excelphp->getActiveSheet()->getStyle('A' . $row)->getFont()->setSize(14);
                $this->excelphp->getActiveSheet()->getStyle('A' . $row)->getFont()->setBold(true);
                $this->excelphp->getActiveSheet()->mergeCells('A' . $row . ':D' . $row);

                $this->excelphp->getActiveSheet()->setCellValue('E' . $row, 'Status');
                $this->excelphp->getActiveSheet()->getStyle('E' . $row)->getFont()->setSize(14);
                $this->excelphp->getActiveSheet()->getStyle('E' . $row)->getFont()->setBold(true);
                $this->excelphp->getActiveSheet()->mergeCells('E' . $row . ':H' . $row);
                $row++;
                foreach ($fileUploadData as $value) {
                    $this->excelphp->getActiveSheet()->setCellValue('A' . $row, $value['file_name']);
                    $this->excelphp->getActiveSheet()->mergeCells('A' . $row . ':D' . $row);
                    $this->excelphp->getActiveSheet()->setCellValue('E' . $row, $ploadStatus[$value['status']]);
                    $this->excelphp->getActiveSheet()->mergeCells('E' . $row . ':H' . $row);
                    $row++;
                }

                $filename = 'file_upload_report' . time() . '.xls'; //save our workbook as this file name
                header('Content-Type: application/vnd.ms-excel'); //mime type
                header('Content-Disposition: attachment;filename="' . $filename . '"'); //tell browser what's the file name
                header('Cache-Control: max-age=0');
                $objWriter = PHPExcel_IOFactory::createWriter($this->excelphp, 'Excel5');

                $objWriter->save('php://output');
            } else {
                show_404();
            }
        } else {
            redirect('home');
        }
    }

}
